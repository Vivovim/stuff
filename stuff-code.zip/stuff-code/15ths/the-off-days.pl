#!/usr/bin/perl -w
## Thu Jan 19 02:26:45 MST 2023
## Christopher ctopher@mac.com

use strict;


system("15th-days.pl");

system("15th-moons.pl");


exit(0);







